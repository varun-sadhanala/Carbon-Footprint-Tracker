# Carbon Footprint Tracker

The **Carbon Footprint Tracker** is a web application designed to help users calculate their carbon emissions based on their daily activities and provide actionable recommendations to reduce their footprint.

---

## **Features**
- Calculate carbon emissions for activities like travel, electricity usage, and meal consumption.
- Personalized recommendations for reducing emissions.
- User authentication for secure profile management.
- Backend built with Python Flask and MongoDB.
- Frontend built with React.js and styled using Tailwind CSS.
- Fully functional API for communication between frontend and backend.

---

## **Technology Stack**
### Backend:
- **Python Flask**: Lightweight framework for API development.
- **MongoDB**: NoSQL database for storing user and activity data.
- **Flask-PyMongo**: Integration with MongoDB.

### Frontend:
- **React.js**: Library for building user interfaces.
- **Tailwind CSS**: Utility-first CSS framework for responsive design.
- **HTML5 & JavaScript**: Core web technologies.

---

## **Folder Structure**

